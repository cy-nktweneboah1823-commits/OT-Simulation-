#!/bin/bash
# AquaGrid OT Lab - Start Conpot Honeypot
# CY376 Project - Nana Kwaku Tweneboah

set -e

CONPOT_DIR="$HOME/ot-lab"
VENV_DIR="$CONPOT_DIR/conpot-env"
LOG_DIR="/var/log/conpot"

echo "[*] Starting Conpot ICS Honeypot..."

# Create log directory if needed
if [ ! -d "$LOG_DIR" ]; then
  sudo mkdir -p "$LOG_DIR"
  sudo chown $USER:$USER "$LOG_DIR"
fi

# Activate virtual environment
if [ -f "$VENV_DIR/bin/activate" ]; then
  source "$VENV_DIR/bin/activate"
else
  echo "[!] Virtual environment not found at $VENV_DIR"
  echo "    Run the setup steps in the README first."
  exit 1
fi

# Start Conpot
# -f          = foreground (remove for background)
# --template  = use default ICS template
# -l          = text log
# json log is written via config / additional flags depending on version

echo "[+] Conpot starting on ports 502 (Modbus) and 102 (S7comm)..."
echo "[+] Logs: $LOG_DIR"
echo ""

conpot -f --template default \
  -l "$LOG_DIR/conpot.log" \
  --logfile "$LOG_DIR/conpot.json"
