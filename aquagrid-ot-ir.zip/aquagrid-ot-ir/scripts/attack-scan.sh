#!/bin/bash
# AquaGrid OT Lab - Port & Service Scan Simulation
# CY376 Project - Nana Kwaku Tweneboah
#
# Usage: ./attack-scan.sh <TARGET-IP>

set -e

if [ -z "$1" ]; then
  echo "Usage: $0 <TARGET-IP>"
  exit 1
fi

TARGET="$1"

echo "[*] AquaGrid OT Lab - Reconnaissance Scan"
echo "[*] Target: $TARGET"
echo ""

# Check if nmap is installed
if ! command -v nmap &> /dev/null; then
  echo "[!] nmap not found. Installing..."
  sudo apt update && sudo apt install -y nmap
fi

echo "[>] Scanning common ICS ports (102, 502, 44818, 20000, 47808)..."
nmap -sS -sV -p 102,502,44818,20000,47808 --open "$TARGET"

echo ""
echo "[>] Quick UDP scan on common ICS ports..."
sudo nmap -sU -p 161,502,47808 --open "$TARGET" || true

echo ""
echo "[*] Scan complete. Check Wazuh for reconnaissance-related alerts."
