#!/usr/bin/env python3
"""
AquaGrid OT Lab - Legitimate-looking Modbus Read
CY376 Project - Nana Kwaku Tweneboah

Simulates normal engineering / HMI traffic by reading holding registers.
This should generate only low-level or informational alerts (if any).

Usage:
  python3 attack-modbus-read.py <CONPOT-IP> [port]
"""

import sys

try:
    from pymodbus.client import ModbusTcpClient
except ImportError:
    print("[!] pymodbus not installed. Run: pip3 install pymodbus")
    sys.exit(1)


def main():
    if len(sys.argv) < 2:
        print(f"Usage: {sys.argv[0]} <CONPOT-IP> [port]")
        sys.exit(1)

    host = sys.argv[1]
    port = int(sys.argv[2]) if len(sys.argv) > 2 else 502

    print(f"[*] Connecting to {host}:{port}")
    client = ModbusTcpClient(host, port=port, timeout=5)

    if not client.connect():
        print("[!] Connection failed")
        sys.exit(1)

    print("[+] Connected. Performing register reads (benign traffic)...\n")

    # Read holding registers (FC03)
    result = client.read_holding_registers(0, 10, slave=1)
    if not result.isError():
        print(f"[+] Holding registers 0-9: {result.registers}")
    else:
        print(f"[!] Error: {result}")

    # Read coils (FC01)
    result = client.read_coils(0, 8, slave=1)
    if not result.isError():
        print(f"[+] Coils 0-7: {result.bits[:8]}")
    else:
        print(f"[!] Error: {result}")

    # Read input registers (FC04)
    result = client.read_input_registers(0, 5, slave=1)
    if not result.isError():
        print(f"[+] Input registers 0-4: {result.registers}")
    else:
        print(f"[!] Error: {result}")

    client.close()
    print("\n[*] Read simulation complete.")


if __name__ == "__main__":
    main()
